Roodepoort SPCA website

overview

I added the wireframes because I forgot to add the screenshot of it that was created using canva.
Ive added the sitemap which was also created on canva.
Ive added my second proposal that
